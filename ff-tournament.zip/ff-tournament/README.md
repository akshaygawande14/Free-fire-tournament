# Free Fire Duo Tournament Site (secure backend)

## What it protects
- Passwords and team PINs are stored only as bcrypt hashes (never plain text), checked on the server.
- Login uses an HttpOnly, SameSite=Strict, Secure cookie that expires in 30 minutes. JavaScript cannot read it.
- Role checks are on the server: only a manager session can reach `/api/m/*` (results, teams, notice, passwords).
- Players only receive team names and points. Another team's Team ID, player names and PIN are never sent to them. Your own team is shown only after Team ID + PIN.
- Rate limits (10 tries / 15 min per IP) plus a 5-minute lock on a team after 5 wrong PINs.
- Changing the entry password instantly logs out all players. Changing the manager password logs the manager out.
- Helmet security headers and a strict Content-Security-Policy, request size limit, CSRF header + SameSite, input validation, parameterised SQL.
- Stores only in-game names. No phone, email, real names, analytics, trackers or third-party scripts.
- No background jobs: the server only does work when someone sends a request.
- Manager activity log (Security tab).

## Player kills column
Each match result now records kills for Player 1 and Player 2 separately. Team kills = P1 + P2 (used for team points). The Table tab shows a "Player Kills (career)" leaderboard, and each team sees its own two players' career kills in My Team.

## Run it
1. Install Node.js 20.6 or newer.
2. `npm install`
3. `cp .env.example .env`, then fill in `JWT_SECRET` (generate with the command inside the file), `ENTRY_PASSWORD` (8+ chars) and `MANAGER_PASSWORD` (10+ chars).
4. `npm start`, then open http://localhost:3000
5. After the first start, delete the two passwords from `.env`. From then on change them in Manager > Security.

## Put it online
Use a host with HTTPS and a persistent disk (the data is a SQLite file at `DB_PATH`), such as Render, Railway, Fly.io or a small VPS. Set the same environment variables in the host's dashboard (not in files), point `DB_PATH` at the persistent disk, and keep `NODE_ENV=production`. Back up the `.db` file before each tournament.

## Limits to know
- Anyone with the entry password can see the points table, so share it only with registered players. Rotate it after each event.
- Use long unique passwords for the manager and give team PINs privately.
- This does not stop a large DDoS attack. For that, put the site behind Cloudflare (free plan).

## Hosting from GitHub
GitHub Pages cannot run this server (it only hosts static files). Put the code in a private GitHub repo (`.env` and `data/` are already ignored by `.gitignore`), then connect the repo to Render, Railway or Fly.io, which deploy from GitHub automatically on every push. Add the environment variables in their dashboard and attach a persistent disk for `DB_PATH`.
