const express = require('express'), helmet = require('helmet'), rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken'), bcrypt = require('bcryptjs'), cookieParser = require('cookie-parser');
const Database = require('better-sqlite3'), path = require('path'), fs = require('fs');
const { JWT_SECRET, ENTRY_PASSWORD, MANAGER_PASSWORD, PORT = 3000, NODE_ENV, DB_PATH = './data/tournament.db' } = process.env;
const PROD = NODE_ENV === 'production';

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL'); db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS teams(id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, p1 TEXT NOT NULL, p2 TEXT NOT NULL,
  pin TEXT NOT NULL, fails INTEGER DEFAULT 0, locked_until INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS matches(n INTEGER PRIMARY KEY AUTOINCREMENT);
CREATE TABLE IF NOT EXISTS results(match_n INTEGER REFERENCES matches(n) ON DELETE CASCADE,
  team_id TEXT REFERENCES teams(id) ON DELETE CASCADE, pos INTEGER NOT NULL, kills INTEGER NOT NULL, PRIMARY KEY(match_n, team_id));
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT DEFAULT CURRENT_TIMESTAMP, action TEXT NOT NULL);`);
const cols = db.prepare('PRAGMA table_info(results)').all().map(c => c.name);
if (!cols.includes('k1')) db.exec('ALTER TABLE results ADD COLUMN k1 INTEGER NOT NULL DEFAULT 0; ALTER TABLE results ADD COLUMN k2 INTEGER NOT NULL DEFAULT 0; UPDATE results SET k1=kills;');
const get = k => db.prepare('SELECT v FROM settings WHERE k=?').get(k)?.v;
const set = (k, v) => db.prepare('INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v').run(k, String(v));
const log = a => db.prepare('INSERT INTO audit(action) VALUES(?)').run(a);

if (!JWT_SECRET || JWT_SECRET.length < 32) { console.error('Set JWT_SECRET (32+ chars) in .env'); process.exit(1); }
if (!get('entry')) {
  if (!ENTRY_PASSWORD || !MANAGER_PASSWORD || ENTRY_PASSWORD.length < 8 || MANAGER_PASSWORD.length < 10) {
    console.error('First start: set ENTRY_PASSWORD (8+) and MANAGER_PASSWORD (10+) in .env'); process.exit(1);
  }
  set('entry', bcrypt.hashSync(ENTRY_PASSWORD, 12)); set('mgr', bcrypt.hashSync(MANAGER_PASSWORD, 12));
  set('tv', 1); set('mv', 1);
  set('notice', 'Welcome! Check the points table and rules.');
  set('rules', '1. Duo vs Duo only.\n2. No hacks or cheating tools.\n3. Join the custom room 10 minutes early.\n4. Manager decisions are final.\n5. Points: placement (1st=12 ... 10th=1) + 1 per kill.');
  log('System created');
}

const PL = [12, 9, 8, 7, 6, 5, 4, 3, 2, 1], pts = (p, k) => (PL[p - 1] || 0) + k;
function board() {
  const rs = db.prepare('SELECT * FROM results').all();
  return db.prepare('SELECT id,name FROM teams').all().map(t => {
    const r = rs.filter(x => x.team_id === t.id);
    return { id: t.id, name: t.name, m: r.length, k: r.reduce((a, x) => a + x.kills, 0), p: r.reduce((a, x) => a + pts(x.pos, x.kills), 0) };
  }).sort((a, b) => b.p - a.p || b.k - a.k || a.name.localeCompare(b.name)).map((t, i) => ({ ...t, r: i + 1 }));
}

function players() { // career kills per single player (slot k1 = player 1, k2 = player 2)
  const rs = db.prepare('SELECT * FROM results').all(), out = [];
  db.prepare('SELECT id,name,p1,p2 FROM teams').all().forEach(t => {
    const r = rs.filter(x => x.team_id === t.id);
    [[t.p1, 'k1'], [t.p2, 'k2']].forEach(([n, f]) => out.push({ id: t.id, name: n, team: t.name, m: r.length, k: r.reduce((a, x) => a + x[f], 0) }));
  });
  return out.sort((a, b) => b.k - a.k || a.name.localeCompare(b.name)).map((p, i) => ({ ...p, r: i + 1 }));
}

const app = express();
if (PROD) app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'none'"], scriptSrc: ["'self'"], styleSrc: ["'self'"],
  connectSrc: ["'self'"], imgSrc: ["'self'"], formAction: ["'self'"], frameAncestors: ["'none'"], baseUri: ["'none'"] } } }));
app.use(express.json({ limit: '10kb' }));
app.use(cookieParser());
app.use((req, res, next) => { // CSRF: custom header cannot be sent cross-site; plus SameSite=Strict cookie
  if (req.method !== 'GET' && req.get('x-requested-with') !== 'ff') return res.status(403).json({ error: 'Blocked' });
  res.set('Cache-Control', 'no-store'); next();
});
app.use(express.static(path.join(__dirname, 'public'), { setHeaders: r => r.set('Cache-Control', 'no-cache') }));

const ver = r => +get(r === 'm' ? 'mv' : 'tv');
const issue = (res, p) => res.cookie('ff', jwt.sign({ ...p, v: ver(p.r) }, JWT_SECRET, { expiresIn: '30m' }),
  { httpOnly: true, sameSite: 'strict', secure: PROD, maxAge: 30 * 60 * 1000, path: '/' });
function readUser(req) { try { const d = jwt.verify(req.cookies.ff, JWT_SECRET); return d.v === ver(d.r) ? d : null; } catch { return null; } }
const auth = (req, res, next) => { req.u = readUser(req); req.u ? next() : res.status(401).json({ error: 'Please log in' }); };
const mgr = (req, res, next) => req.u.r === 'm' ? next() : res.status(403).json({ error: 'Managers only' });
const bad = (res, m) => res.status(400).json({ error: m });
const str = (s, max) => typeof s === 'string' && s.trim().length > 0 && s.trim().length <= max ? s.trim() : null;
const wrap = f => (q, s, n) => { try { f(q, s, n); } catch (e) { console.error(e.message); s.status(500).json({ error: 'Server error' }); } };

const loginLimit = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many attempts. Try again in 15 minutes.' } });

app.get('/api/session', (req, res) => { const u = readUser(req); res.json({ role: u?.r || null, team: !!u?.t }); });
app.post('/api/login', loginLimit, wrap(async (req, res) => {
  const { password, manager } = req.body || {};
  if (typeof password !== 'string' || password.length > 200) return bad(res, 'Invalid');
  const isM = manager === true;
  if (!(await bcrypt.compare(password, get(isM ? 'mgr' : 'entry')))) return res.status(401).json({ error: 'Wrong password' });
  issue(res, { r: isM ? 'm' : 'p' }); if (isM) log('Manager logged in');
  res.json({ role: isM ? 'm' : 'p' });
}));
app.post('/api/logout', (req, res) => { res.clearCookie('ff'); res.json({ ok: 1 }); });

app.post('/api/team-login', auth, loginLimit, wrap(async (req, res) => {
  if (req.u.r !== 'p') return bad(res, 'Players only');
  const id = String(req.body?.id || '').trim().toUpperCase(), pin = String(req.body?.pin || '');
  const t = db.prepare('SELECT * FROM teams WHERE id=?').get(id);
  if (!t) return res.status(401).json({ error: 'Wrong Team ID or PIN' });
  if (t.locked_until > Date.now()) return res.status(429).json({ error: 'Team locked for a few minutes' });
  if (!(await bcrypt.compare(pin, t.pin))) {
    const f = t.fails + 1;
    db.prepare('UPDATE teams SET fails=?, locked_until=? WHERE id=?').run(f >= 5 ? 0 : f, f >= 5 ? Date.now() + 5 * 60000 : 0, id);
    return res.status(401).json({ error: 'Wrong Team ID or PIN' });
  }
  db.prepare('UPDATE teams SET fails=0 WHERE id=?').run(id);
  issue(res, { r: 'p', t: id }); res.json({ ok: 1 });
}));
app.post('/api/team-logout', auth, (req, res) => { issue(res, { r: req.u.r }); res.json({ ok: 1 }); });

app.get('/api/table', auth, (req, res) => {
  const b = board().map(t => req.u.r === 'm' ? t : { name: t.name, m: t.m, k: t.k, p: t.p, r: t.r });
  res.json({ board: b, players: players().map(p => ({ r: p.r, name: p.name, team: p.team, m: p.m, k: p.k })), notice: get('notice'), rules: get('rules') });
});
app.get('/api/me', auth, (req, res) => {
  if (!req.u.t) return res.status(403).json({ error: 'Open your team first' });
  const t = db.prepare('SELECT id,name,p1,p2 FROM teams WHERE id=?').get(req.u.t);
  if (!t) return res.status(404).json({ error: 'Team not found' });
  const me = board().find(x => x.id === t.id);
  const ms = db.prepare('SELECT match_n n,pos,kills,k1,k2 FROM results WHERE team_id=? ORDER BY match_n').all(t.id).map(x => ({ ...x, pts: pts(x.pos, x.kills) }));
  const pk = [t.p1, t.p2].map((n, i) => ({ name: n, k: ms.reduce((a, x) => a + (i ? x.k2 : x.k1), 0) }));
  res.json({ team: { name: t.name, p1: t.p1, p2: t.p2, r: me.r, p: me.p, k: me.k, m: me.m, pk }, matches: ms });
});

const M = express.Router(); app.use('/api/m', auth, mgr, M);
M.get('/teams', (q, s) => s.json(db.prepare('SELECT id,name,p1,p2 FROM teams ORDER BY id').all()));
M.post('/teams', wrap(async (q, s) => {
  const name = str(q.body?.name, 30), p1 = str(q.body?.p1, 30), p2 = str(q.body?.p2, 30), pin = q.body?.pin;
  if (!name || !p1 || !p2 || typeof pin !== 'string' || pin.length < 4 || pin.length > 40) return bad(s, 'Fill all fields. PIN needs 4+ characters.');
  if (db.prepare('SELECT 1 FROM teams WHERE name=?').get(name)) return bad(s, 'Team name already exists');
  const n = (db.prepare("SELECT MAX(CAST(SUBSTR(id,2) AS INTEGER)) m FROM teams").get().m || 0) + 1, id = 'T' + String(n).padStart(2, '0');
  db.prepare('INSERT INTO teams(id,name,p1,p2,pin) VALUES(?,?,?,?,?)').run(id, name, p1, p2, await bcrypt.hash(pin, 10));
  log('Added team ' + id); s.json({ id });
}));
M.delete('/teams/:id', (q, s) => { db.prepare('DELETE FROM teams WHERE id=?').run(q.params.id); log('Deleted team ' + q.params.id); s.json({ ok: 1 }); });
M.post('/teams/:id/pin', wrap(async (q, s) => {
  const pin = q.body?.pin; if (typeof pin !== 'string' || pin.length < 4 || pin.length > 40) return bad(s, 'PIN needs 4+ characters');
  db.prepare('UPDATE teams SET pin=?,fails=0,locked_until=0 WHERE id=?').run(await bcrypt.hash(pin, 10), q.params.id);
  log('Reset PIN ' + q.params.id); s.json({ ok: 1 });
}));
M.get('/matches', (q, s) => {
  const ms = db.prepare('SELECT n FROM matches ORDER BY n').all(), rs = db.prepare('SELECT * FROM results').all();
  s.json(ms.map(m => ({ n: m.n, results: Object.fromEntries(rs.filter(r => r.match_n === m.n).map(r => [r.team_id, { pos: r.pos, kills: r.kills, k1: r.k1, k2: r.k2 }])) })));
});
M.post('/matches', (q, s) => { const n = db.prepare('INSERT INTO matches DEFAULT VALUES').run().lastInsertRowid; log('New match ' + n); s.json({ n }); });
M.put('/matches/:n', (q, s) => {
  const n = +q.params.n, list = q.body?.results;
  if (!db.prepare('SELECT 1 FROM matches WHERE n=?').get(n) || !Array.isArray(list) || list.length > 100) return bad(s, 'Invalid');
  const ok = list.every(r => typeof r.team === 'string' && Number.isInteger(r.pos) && r.pos >= 1 && r.pos <= 12 && Number.isInteger(r.k1) && r.k1 >= 0 && r.k1 <= 30 && Number.isInteger(r.k2) && r.k2 >= 0 && r.k2 <= 30);
  if (!ok) return bad(s, 'Position must be 1-12 and each player kills 0-30');
  db.transaction(() => {
    db.prepare('DELETE FROM results WHERE match_n=?').run(n);
    for (const r of list) if (db.prepare('SELECT 1 FROM teams WHERE id=?').get(r.team)) db.prepare('INSERT INTO results(match_n,team_id,pos,kills,k1,k2) VALUES(?,?,?,?,?,?)').run(n, r.team, r.pos, r.k1 + r.k2, r.k1, r.k2);
  })(); log('Saved results for match ' + n); s.json({ ok: 1 });
});
M.put('/notice', (q, s) => {
  const a = str(q.body?.notice, 1000), b = str(q.body?.rules, 4000); if (!a || !b) return bad(s, 'Notice and rules are required');
  set('notice', a); set('rules', b); log('Edited notice/rules'); s.json({ ok: 1 });
});
M.put('/entry-password', wrap(async (q, s) => {
  const p = q.body?.password; if (typeof p !== 'string' || p.length < 8 || p.length > 100) return bad(s, 'Minimum 8 characters');
  set('entry', await bcrypt.hash(p, 12)); set('tv', +get('tv') + 1); log('Changed entry password (players logged out)');
  issue(s, { r: 'm' }); s.json({ ok: 1 });
}));
M.put('/manager-password', wrap(async (q, s) => {
  const { current, password } = q.body || {};
  if (typeof current !== 'string' || !(await bcrypt.compare(current, get('mgr')))) return bad(s, 'Current password is wrong');
  if (typeof password !== 'string' || password.length < 10 || password.length > 100) return bad(s, 'Minimum 10 characters');
  set('mgr', await bcrypt.hash(password, 12)); set('mv', +get('mv') + 1); log('Changed manager password');
  s.clearCookie('ff'); s.json({ ok: 1 });
}));
M.get('/audit', (q, s) => s.json(db.prepare('SELECT at,action FROM audit ORDER BY id DESC LIMIT 50').all()));

app.use('/api', (q, s) => s.status(404).json({ error: 'Not found' }));
app.use((e, q, s, n) => { console.error(e.message); s.status(400).json({ error: 'Bad request' }); });
app.listen(PORT, () => console.log('Running on port ' + PORT));
