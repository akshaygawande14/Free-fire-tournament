const $ = i => document.getElementById(i);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let role = null, hasTeam = false, tab = 'table', mode = 'p', cur = null, idle, arm = '';

async function api(method, url, body) {
  const r = await fetch(url, { method, credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'ff' }, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({}));
  if (r.status === 401 && role) { role = null; render('Session ended. Please log in again.'); }
  if (!r.ok) throw new Error(d.error || 'Something went wrong');
  return d;
}
const say = (t, ok) => { const m = $('msg'); if (m) { m.textContent = t; m.className = ok ? 'ok' : 'err'; } };
const pingIdle = () => { if (!role) return; clearTimeout(idle); idle = setTimeout(() => A.logout({ m: 'Logged out after 5 minutes of inactivity.' }), 300000); };
['pointerdown', 'keydown'].forEach(e => addEventListener(e, pingIdle));

const tabsFor = () => role === 'm' ? [['table', 'Table'], ['results', 'Results'], ['teams', 'Teams'], ['info', 'Notice'], ['sec', 'Security']]
  : [['table', 'Table'], ['mine', 'My Team'], ['rules', 'Rules']];

async function render(msg) {
  const a = $('app');
  if (!role) {
    a.innerHTML = `<div class=card><h1>🔥 Free Fire Duo Tournament</h1><p class=mu>${mode === 'm' ? 'Manager login' : 'Enter the access password given by the organisers.'}</p>
<input id=pw type=password autocomplete=off placeholder="${mode === 'm' ? 'Manager password' : 'Access password'}">
<button data-a=login>Enter</button><p id=msg class=err>${msg ? esc(msg) : ''}</p>
<a data-a=mode>${mode === 'm' ? 'Back to player login' : 'Manager login'}</a></div>`;
    return;
  }
  let h = `<div class=tabs>${tabsFor().map(x => `<button class="${tab === x[0] ? 'on' : ''}" data-a=tab data-t=${x[0]}>${x[1]}</button>`).join('')}<button class=g data-a=logout>Log out</button></div>`;
  try { h += await V[tab](); } catch (e) { h += `<div class=card><p class=err>${esc(e.message)}</p></div>`; }
  a.innerHTML = h;
}

const tbl = b => b.length ? `<div class=w><table><tr><th>#</th><th>Team</th><th>M</th><th>Kills</th><th>Pts</th></tr>${b.map(t =>
  `<tr><td>${t.r}</td><td>${esc(t.name)}</td><td>${t.m}</td><td>${t.k}</td><td><b>${t.p}</b></td></tr>`).join('')}</table></div>` : '<p class=mu>No teams yet.</p>';

const ptbl = b => b.length ? `<div class=w><table><tr><th>#</th><th>Player</th><th>Team</th><th>M</th><th>Career kills</th></tr>${b.map(p =>
  `<tr><td>${p.r}</td><td>${esc(p.name)}</td><td>${esc(p.team)}</td><td>${p.m}</td><td><b>${p.k}</b></td></tr>`).join('')}</table></div>` : '<p class=mu>No players yet.</p>';

const V = {
  async table() { const d = await api('GET', '/api/table');
    return `<div class=card><h2>📢 Notice</h2><pre>${esc(d.notice)}</pre></div><div class=card><h2>Points Table</h2>${tbl(d.board)}</div><div class=card><h2>Player Kills (career)</h2>${ptbl(d.players)}</div>`; },
  async rules() { const d = await api('GET', '/api/table'); return `<div class=card><h2>Rules &amp; Instructions</h2><pre>${esc(d.rules)}</pre></div>`; },
  async mine() {
    if (!hasTeam) return `<div class=card><h2>My Team</h2><p class=mu>Enter the Team ID and PIN given by your manager.</p>
<input id=tid placeholder="Team ID (e.g. T01)" autocomplete=off><input id=tpin type=password placeholder="Team PIN" autocomplete=off>
<button data-a=tlogin>Open</button><p id=msg class=err></p></div>`;
    const d = await api('GET', '/api/me'), t = d.team;
    return `<div class=card><h2>${esc(t.name)}</h2><p class=mu>${esc(t.p1)} &amp; ${esc(t.p2)}</p><div class=row>
<div><div class=big>#${t.r}</div><span class=mu>Rank</span></div><div><div class=big>${t.p}</div><span class=mu>Points</span></div>
<div><div class=big>${t.k}</div><span class=mu>Kills</span></div></div><p class=mu>Career kills: ${t.pk.map(x => `${esc(x.name)}: <b>${x.k}</b>`).join(' · ')}</p></div>
<div class=card><h2>My Matches</h2>${d.matches.length ? `<div class=w><table><tr><th>Match</th><th>Position</th><th>${esc(t.p1)}</th><th>${esc(t.p2)}</th><th>Pts</th></tr>${d.matches.map(m =>
      `<tr><td>${m.n}</td><td>${m.pos}</td><td>${m.k1}</td><td>${m.k2}</td><td>${m.pts}</td></tr>`).join('')}</table></div>` : '<p class=mu>No results yet.</p>'}
<button class=g data-a=closeTeam>Close my team</button></div>`; },
  async results() {
    const [teams, ms] = await Promise.all([api('GET', '/api/m/teams'), api('GET', '/api/m/matches')]);
    if (!teams.length) return '<div class=card><p class=mu>Add teams first.</p></div>';
    if (cur === null || !ms.find(m => m.n === cur)) cur = ms.length ? ms[ms.length - 1].n : null;
    const m = ms.find(x => x.n === cur);
    return `<div class=card><h2>Enter Match Results</h2><select data-a=pick>${ms.map(x => `<option value=${x.n} ${x.n === cur ? 'selected' : ''}>Match ${x.n}</option>`).join('')}</select>
<button class=g data-a=newMatch>+ New match</button>${m ? `<div class=w><table><tr><th>Team</th><th>Pos</th><th>P1 kills</th><th>P2 kills</th></tr>${teams.map(t => {
      const r = m.results[t.id]; return `<tr><td>${esc(t.name)}<br><span class=mu>${esc(t.p1)} / ${esc(t.p2)}</span></td><td><input data-p=${t.id} type=number min=1 max=12 value="${r ? r.pos : ''}"></td><td><input data-k1=${t.id} type=number min=0 max=30 value="${r ? r.k1 : ''}"></td><td><input data-k2=${t.id} type=number min=0 max=30 value="${r ? r.k2 : ''}"></td></tr>`; }).join('')}</table></div>
<button data-a=saveRes>Save results</button>` : ''}<p id=msg class=err></p></div>`; },
  async teams() { const t = await api('GET', '/api/m/teams');
    return `<div class=card><h2>Add Team</h2><input id=nn placeholder="Team name" maxlength=30><input id=p1 placeholder="Player 1 in-game name" maxlength=30>
<input id=p2 placeholder="Player 2 in-game name" maxlength=30><input id=np placeholder="Team PIN (min 4 chars)" autocomplete=off>
<p class=mu>Only game names are stored. No phone, email or real names.</p><button data-a=addTeam>Add</button><p id=msg class=err></p></div>
<div class=card><h2>Teams (${t.length})</h2>${t.map(x => `<p><b>${esc(x.id)}</b> ${esc(x.name)} <span class=mu>${esc(x.p1)}, ${esc(x.p2)}</span><br>
<button class=g data-a=delTeam data-id=${esc(x.id)}>${arm === x.id ? 'Tap again to delete' : 'Delete'}</button><button class=g data-a=rpin data-id=${esc(x.id)}>Reset PIN</button></p>`).join('') || '<p class=mu>None yet.</p>'}</div>`; },
  async info() { const d = await api('GET', '/api/table');
    return `<div class=card><h2>Notice</h2><textarea id=nt rows=4 maxlength=1000>${esc(d.notice)}</textarea><h2>Rules</h2><textarea id=rl rows=8 maxlength=4000>${esc(d.rules)}</textarea>
<button data-a=saveInfo>Save</button><p id=msg class=err></p></div>`; },
  async sec() { const log = await api('GET', '/api/m/audit');
    return `<div class=card><h2>Change Entry Password</h2><p class=mu>Players must log in again after this.</p><input id=ne type=password placeholder="New entry password (min 8)" autocomplete=off>
<button data-a=chgE>Change entry password</button><h2>Change Manager Password</h2><input id=cm type=password placeholder="Current manager password" autocomplete=off>
<input id=nm type=password placeholder="New manager password (min 10)" autocomplete=off><button data-a=chgM>Change manager password</button><p id=msg class=err></p></div>
<div class=card><h2>Activity log</h2><div class=w><table>${log.map(l => `<tr><td class=mu>${esc(l.at)}</td><td>${esc(l.action)}</td></tr>`).join('')}</table></div></div>`; }
};

const run = f => async d => { try { await f(d); } catch (e) { say(e.message); } };
const A = {
  login: run(async () => { const r = await api('POST', '/api/login', { password: $('pw').value, manager: mode === 'm' });
    role = r.role; hasTeam = false; tab = 'table'; pingIdle(); render(); }),
  mode: () => { mode = mode === 'm' ? 'p' : 'm'; render(); },
  tab: d => { tab = d.t; arm = ''; render(); },
  logout: async d => { try { await api('POST', '/api/logout'); } catch {} role = null; hasTeam = false; tab = 'table'; mode = 'p'; clearTimeout(idle); render(d && d.m); },
  tlogin: run(async () => { await api('POST', '/api/team-login', { id: $('tid').value, pin: $('tpin').value }); hasTeam = true; render(); }),
  closeTeam: run(async () => { await api('POST', '/api/team-logout'); hasTeam = false; render(); }),
  pick: () => { cur = +document.querySelector('[data-a=pick]').value; render(); },
  newMatch: run(async () => { cur = (await api('POST', '/api/m/matches')).n; render(); }),
  saveRes: run(async () => { const results = [];
    document.querySelectorAll('[data-p]').forEach(p => { const id = p.dataset.p, a = document.querySelector(`[data-k1="${id}"]`).value, b = document.querySelector(`[data-k2="${id}"]`).value;
      if (p.value !== '' || a !== '' || b !== '') results.push({ team: id, pos: parseInt(p.value || '0'), k1: parseInt(a || '0'), k2: parseInt(b || '0') }); });
    await api('PUT', '/api/m/matches/' + cur, { results }); say('Saved.', 1); }),
  addTeam: run(async () => { await api('POST', '/api/m/teams', { name: $('nn').value, p1: $('p1').value, p2: $('p2').value, pin: $('np').value }); render(); }),
  delTeam: run(async d => { if (arm !== d.id) { arm = d.id; return render(); } await api('DELETE', '/api/m/teams/' + d.id); arm = ''; render(); }),
  rpin: run(async d => { const pin = prompt('New PIN for ' + d.id + ' (min 4 chars)'); if (pin) { await api('POST', `/api/m/teams/${d.id}/pin`, { pin }); alert('PIN changed'); } }),
  saveInfo: run(async () => { await api('PUT', '/api/m/notice', { notice: $('nt').value, rules: $('rl').value }); say('Saved.', 1); }),
  chgE: run(async () => { await api('PUT', '/api/m/entry-password', { password: $('ne').value }); say('Entry password changed.', 1); }),
  chgM: run(async () => { await api('PUT', '/api/m/manager-password', { current: $('cm').value, password: $('nm').value });
    role = null; mode = 'm'; render('Manager password changed. Log in again.'); })
};
document.addEventListener('click', e => { const b = e.target.closest('[data-a]'); if (b && b.tagName !== 'SELECT' && A[b.dataset.a]) A[b.dataset.a](b.dataset); });
document.addEventListener('change', e => { if (e.target.dataset.a === 'pick') A.pick(); });
document.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.id === 'pw') A.login(); });
fetch('/api/session', { credentials: 'same-origin' }).then(r => r.json()).then(s => { role = s.role; hasTeam = s.team; pingIdle(); render(); });
